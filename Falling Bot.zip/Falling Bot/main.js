const canvas = document.getElementById("canvas")
const ctx = canvas.getContext("2d")
const scrBoard = document.getElementById("score")

const buttonEsq = document.getElementById("esq")
buttonEsq.addEventListener("touchstart", esqClickStart)
buttonEsq.addEventListener("touchend", esqClickEnd)

const buttonDire = document.getElementById("dire")
buttonDire.addEventListener("touchstart", direClickStart)
buttonDire.addEventListener("touchend", direClickEnd)

var start = new Image()
start.src = "sprites/start.png"

start.onload = function() {
    ctx.drawImage(start, 125, 175)
}

canvas.addEventListener("click", clicking)
clickStt = 1
function clicking() {
    if (clickStt == 1) {
        everything()
    }
    if (clickStt == 2) {
        
    }
}

//sprites

var botStopped = new Image()
botStopped.src = "sprites/stopped.png"

var botLeft = new Image()
botLeft.src = "sprites/moving_left.png"

var botRight = new Image()
botRight.src = "sprites/moving_right.png"

var botDead = new Image()
botDead.src = "sprites/dead_bot.png"

var direction = botStopped

//directions

function esqClickStart() {
    direction = botLeft
    directionBot = 1
}
function esqClickEnd() {
    direction = botStopped
    directionBot = 0
}


function direClickStart() {
    direction = botRight
    directionBot = 2
}
function direClickEnd() {
    direction = botStopped
    directionBot = 0
}

//bot

function everything() {
    
ctx.clearRect(0, 0, 300, 400)
direction = botStopped

clickStt = 2

botX = 140
botY = 20

botFloor = botY + 25

directionBot = 0
gravityBot = 1

function bot() {
    ctx.clearRect(botX, botY, 25, 25)
    if (directionBot == 0) {
        
    }
    if (directionBot == 1) {
        botX -= 3
    }
    if (directionBot == 2) {
        botX += 3
    }
    
    if (gravityBot == 0) {
        botY -= 3
    }
    if (gravityBot == 1) {
        botY += 3
    }
    ctx.drawImage(direction, botX, botY, 25, 25)
    
    if (botX > 301) {
        botX = 0
    }
    if (botX + 25 < 0) {
        botX = 300
    }
}
var botWorking = setInterval(bot, 1)

//plattforms

var plattform = new Image()
plattform.src = "sprites/plattform.png"

var spike = new Image()
spike.src = "sprites/spike.png"


p1X = 125
p1Y = 400

function p1() {
    ctx.clearRect(p1X, p1Y, 75, 15)
    p1Y -= 2
    ctx.drawImage(plattform, p1X, p1Y, 75, 15)
    
    if (p1Y < -15) {
        p1Y = p4Y + 115
        p1X = Math.floor(Math.random() * 225)
    }
}
var p1Working = setInterval(p1, 1)

p2X = Math.floor(Math.random() * 225)
p2Y = 500

function p2() {
    ctx.clearRect(p2X, p2Y, 75, 15)
    p2Y -= 2
    ctx.drawImage(spike, p2X, p2Y, 75, 15)
    
    if (p2Y < -15) {
        p2Y = p1Y + 115
        p2X = Math.floor(Math.random() * 225)
        score += 10
        scrBoard.innerText = "Score: " + score
    }
}
var p2Working = setInterval(p2, 1)

p3X = Math.floor(Math.random() * 225)
p3Y = 600

function p3() {
    ctx.clearRect(p3X, p3Y, 75, 15)
    p3Y -= 2
    ctx.drawImage(plattform, p3X, p3Y, 75, 15)

    if (p3Y < -15) {
        p3Y = p2Y + 115
        p3X = Math.floor(Math.random() * 225)
    }
}
var p3Working = setInterval(p3, 1)

p4X = Math.floor(Math.random() * 225)
p4Y = 700

function p4() {
    ctx.clearRect(p4X, p4Y, 75, 15)
    p4Y -= 2
    ctx.drawImage(spike, p4X, p4Y, 75, 15)

    if (p4Y < -15) {
        p4Y = p3Y + 115
        p4X = Math.floor(Math.random() * 225)
        score += 10
        scrBoard.innerText = "Score: " + score
    }
}
var p4Working = setInterval(p4, 1)

//colisions

function colisions() {
    if (botX + 25 > p1X &&
        p1X + 75 > botX &&
        botY + 27 > p1Y &&
        p1Y + 15 > botY) {
        gravityBot = 0
    } else {
        if (botX + 25 > p2X &&
            p2X + 75 > botX &&
            botY + 27 > p2Y &&
            p2Y + 15 > botY) {
                direction = botDead
                dead()
                gravityBot = 0
        } else {
            if (botX + 25 > p3X &&
            p3X + 75 > botX &&
            botY + 27 > p3Y &&
            p3Y + 15 > botY) {
                gravityBot = 0
            } else {
                if (botX + 25 > p4X &&
                    p4X + 75 > botX &&
                    botY + 27 > p4Y &&
                    p4Y + 15 > botY) {
                    direction = botDead
                    dead()
                    gravityBot = 0
            } else {
                gravityBot = 1
            }
        }
    }
}
}
setInterval(colisions, 1)

//spikes

var spikesUp = new Image()
spikesUp.src = "sprites/spikes_up.png"

var spikesDown = new Image()
spikesDown.src = "sprites/spikes_down.png"

function drawSpikes() {
    ctx.drawImage(spikesUp, 0, 0, 300, 10)
    ctx.drawImage(spikesDown, 0, 390, 300, 10)
}
var spikesWorking = setInterval(drawSpikes, 1)

//clouds

var cloud1 = new Image()
cloud1.src = "sprites/cloud1.png"

cloud1X = Math.floor(Math.random() * 300)
cloud1Y = Math.floor(Math.random() * 400)

function cloud1Appear() {
    ctx.clearRect(cloud1X, cloud1Y, 20, 20)
    cloud1X -= 2
    ctx.drawImage(cloud1, cloud1X, cloud1Y)
    
    if (cloud1X + 20 < 0) {
        cloud1X = 300
    }
}
var c1Working = setInterval(cloud1Appear, 100)


var cloud2 = new Image()
cloud2.src = "sprites/cloud2.png"

cloud2X = Math.floor(Math.random() * 300)
cloud2Y = Math.floor(Math.random() * 400)

function cloud2Appear() {
    ctx.clearRect(cloud2X, cloud2Y, 40, 20)
    cloud2X -= 4
    ctx.drawImage(cloud2, cloud2X, cloud2Y)
    
    if (cloud2X + 40 < 0) {
        cloud2X = 300
    }
}
var c2Working = setInterval(cloud2Appear, 100)

//death

var deadPic = new Image()
deadPic.src = "sprites/dead.jpg"

function dead() {
    clickStt = 1
    clearInterval(botWorking)
    clearInterval(p1Working)
    clearInterval(p2Working)
    clearInterval(p3Working)
    clearInterval(p4Working)
    clearInterval(spikesWorking)
    clearInterval(c1Working)
    clearInterval(c2Working) 
    ctx.drawImage(deadPic, 0, 0)
}

function deadCheck() {
    if (botY + 25 > 380 || botY < 20) {
        dead()
        clickStt = 1
    }
}
setInterval(deadCheck, 10)

//score

let score = 0

score = 0
scrBoard.innerText = "Score: 0"
}